/* Project: Checker Game for MacOS
 Project for WWDC 2023
 Author: Khang Nguyen Huynh
 Finished on April 15th, 2023
 howtoplay file
 */
import Foundation
import SwiftUI
struct coordinate {
    var x: Int
    var y: Int
}
